# Sistema de Eventos — Protótipo (Console / Java)

## Descrição
Protótipo acadêmico de sistema em Java para cadastrar, listar, confirmar presença e notificar eventos.  
Projeto feito para rodar em **console**.

## Funcionalidades
- Cadastrar eventos (nome, categoria, cidade, endereço, data/hora, descrição)
- Listar eventos cadastrados (ordenados por data)
- Confirmar presença em eventos (bloqueia se já ocorreu)
- Notificar eventos por cidade (próximos 5)
- Relatório com totais por categoria e por cidade

## Requisitos
- Java 17+

## Como executar
```bash
javac -d out src/model/Evento.java src/service/SistemaEventos.java src/app/App.java
java -cp out app.App
```

---
