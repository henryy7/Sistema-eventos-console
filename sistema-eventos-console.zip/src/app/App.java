package app;

import model.Evento;
import service.SistemaEventos;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.Scanner;

public class App {
    private static final Scanner sc = new Scanner(System.in);
    private static final SistemaEventos sistema = new SistemaEventos();
    private static final DateTimeFormatter FMT = DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm");

    public static void main(String[] args) {
        menu();
    }

    private static void menu() {
        int op;
        do {
            System.out.println("\n=== Sistema de Eventos (Protótipo) ===");
            System.out.println("1 - Cadastrar evento");
            System.out.println("2 - Listar eventos");
            System.out.println("3 - Confirmar presença");
            System.out.println("4 - Notificar por cidade");
            System.out.println("5 - Gerar relatório");
            System.out.println("0 - Sair");
            System.out.print("Escolha: ");
            op = lerInt();

            switch (op) {
                case 1 -> cadastrarEventoUI();
                case 2 -> listarEventosUI();
                case 3 -> confirmarPresencaUI();
                case 4 -> notificarUI();
                case 5 -> System.out.println(sistema.gerarRelatorio());
                case 0 -> System.out.println("Encerrando...");
                default -> System.out.println("Opção inválida.");
            }
        } while (op != 0);
    }

    private static void cadastrarEventoUI() {
        System.out.print("Nome: ");
        String nome = sc.nextLine();
        System.out.print("Categoria: ");
        String categoria = sc.nextLine();
        System.out.print("Cidade: ");
        String cidade = sc.nextLine();
        System.out.print("Endereço: ");
        String endereco = sc.nextLine();
        System.out.print("Data e hora (dd/MM/yyyy HH:mm): ");
        String dataStr = sc.nextLine();
        LocalDateTime dataHora = LocalDateTime.parse(dataStr, FMT);
        System.out.print("Descrição: ");
        String desc = sc.nextLine();

        Evento e = new Evento(nome, categoria, cidade, endereco, dataHora, desc);
        try {
            sistema.cadastrar(e);
            System.out.println("ID do evento: " + e.getId());
        } catch (IllegalArgumentException ex) {
            System.out.println("Falha ao cadastrar: " + ex.getMessage());
        }
    }

    private static void listarEventosUI() {
        List<Evento> lista = sistema.listar();
        if (lista.isEmpty()) {
            System.out.println("Nenhum evento cadastrado.");
        } else {
            for (Evento e : lista) System.out.println(e);
        }
    }

    private static void confirmarPresencaUI() {
        System.out.print("ID do evento: ");
        String id = sc.nextLine();
        System.out.print("Seu nome: ");
        String nome = sc.nextLine();
        boolean ok = sistema.confirmarPresenca(id, nome);
        System.out.println(ok ? "Presença confirmada." : "Não foi possível confirmar (evento inexistente ou já ocorreu)." );
    }

    private static void notificarUI() {
        System.out.print("Cidade: ");
        String cidade = sc.nextLine();
        List<Evento> proximos = sistema.notificarPorCidade(cidade, LocalDateTime.now());
        if (proximos.isEmpty()) {
            System.out.println("Sem eventos próximos em " + cidade + ".");
        } else {
            System.out.println("Eventos próximos em " + cidade + ":");
            for (Evento e : proximos) {
                System.out.println("- " + e.getNome() + " em " + e.getDataHora().format(FMT));
            }
        }
    }

    private static int lerInt() {
        try { return Integer.parseInt(sc.nextLine()); }
        catch (Exception e) { return -1; }
    }
}
