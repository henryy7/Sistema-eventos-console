package model;

import java.time.LocalDateTime;
import java.util.UUID;

public class Evento implements Comparable<Evento> {
    private final String id;            // gerado automaticamente
    private String nome;
    private String categoria;
    private String cidade;
    private String endereco;
    private LocalDateTime dataHora;
    private String descricao;

    public Evento(String nome, String categoria, String cidade, String endereco,
                  LocalDateTime dataHora, String descricao) {
        this.id = UUID.randomUUID().toString();
        this.nome = nome;
        this.categoria = categoria;
        this.cidade = cidade;
        this.endereco = endereco;
        this.dataHora = dataHora;
        this.descricao = descricao;
    }

    public String getId() { return id; }
    public String getNome() { return nome; }
    public String getCategoria() { return categoria; }
    public String getCidade() { return cidade; }
    public String getEndereco() { return endereco; }
    public LocalDateTime getDataHora() { return dataHora; }
    public String getDescricao() { return descricao; }

    public void setNome(String nome) { this.nome = nome; }
    public void setCategoria(String categoria) { this.categoria = categoria; }
    public void setCidade(String cidade) { this.cidade = cidade; }
    public void setEndereco(String endereco) { this.endereco = endereco; }
    public void setDataHora(LocalDateTime dataHora) { this.dataHora = dataHora; }
    public void setDescricao(String descricao) { this.descricao = descricao; }

    @Override
    public String toString() {
        return "[" + id.substring(0, 8) + "] " + nome + " (" + categoria + ") - "
                + dataHora + " @ " + endereco + ", " + cidade;
    }

    @Override
    public int compareTo(Evento outro) {
        return this.dataHora.compareTo(outro.dataHora);
    }
}
