package service;

import model.Evento;

import java.time.LocalDateTime;
import java.util.*;
import java.util.stream.Collectors;

public class SistemaEventos {
    private static boolean isBlank(String s) { return s == null || s.trim().isEmpty(); }
    private final List<Evento> eventos = new ArrayList<>();
    private final Map<String, Set<String>> presencas = new HashMap<>(); // eventoId -> nomes

    public void cadastrar(Evento e) {
        if (e == null) throw new IllegalArgumentException("Evento inválido");
        if (isBlank(e.getNome()) || isBlank(e.getCategoria()) || isBlank(e.getCidade())
                || isBlank(e.getEndereco()) || e.getDataHora() == null) {
            throw new IllegalArgumentException("Preencha todos os campos obrigatórios.");
        }
        if (e.getDataHora().isBefore(LocalDateTime.now())) {
            throw new IllegalArgumentException("A data/hora do evento deve ser no futuro.");
        }
        eventos.add(e);
        System.out.println("Evento cadastrado: " + e.getNome());
    }

    public List<Evento> listar() {
        if (eventos.isEmpty()) return Collections.emptyList();
        List<Evento> copia = new ArrayList<>(eventos);
        copia.sort(Comparator.comparing(Evento::getDataHora));
        return Collections.unmodifiableList(copia);
    }

    public Evento buscarPorId(String id) {
        for (Evento e : eventos) if (e.getId().equals(id)) return e;
        return null;
    }

    public boolean confirmarPresenca(String eventoId, String nomeUsuario) {
        Evento e = buscarPorId(eventoId);
        if (e == null) return false;
        if (LocalDateTime.now().isAfter(e.getDataHora())) {
            return false; // não confirmar após a data do evento
        }
        presencas.putIfAbsent(eventoId, new HashSet<>());
        presencas.get(eventoId).add(nomeUsuario);
        return true;
    }

    public List<Evento> notificarPorCidade(String cidade, LocalDateTime aPartirDe) {
        List<Evento> proximos = eventos.stream()
                .filter(e -> e.getCidade().equalsIgnoreCase(cidade)
                        && (e.getDataHora().isAfter(aPartirDe) || e.getDataHora().isEqual(aPartirDe)))
                .sorted(Comparator.comparing(Evento::getDataHora))
                .limit(5)
                .collect(Collectors.toList());
        return proximos;
    }

    public String gerarRelatorio() {
        StringBuilder sb = new StringBuilder();
        sb.append("===== RELATÓRIO DE EVENTOS =====\n");
        sb.append("Total de eventos: ").append(eventos.size()).append("\n");

        Map<String, Long> porCategoria = eventos.stream()
                .collect(Collectors.groupingBy(Evento::getCategoria, Collectors.counting()));
        sb.append("--- Por Categoria ---\n");
        porCategoria.forEach((cat, total) -> sb.append(cat).append(": ").append(total).append("\n"));

        Map<String, Long> porCidade = eventos.stream()
                .collect(Collectors.groupingBy(Evento::getCidade, Collectors.counting()));
        sb.append("--- Por Cidade ---\n");
        porCidade.forEach((cid, total) -> sb.append(cid).append(": ").append(total).append("\n"));

        sb.append("--- Detalhes ---\n");
        for (Evento e : eventos) {
            int confirmados = presencas.getOrDefault(e.getId(), Collections.emptySet()).size();
            sb.append("- ").append(e.getNome())
              .append(" | ").append(e.getCidade())
              .append(" | ").append(e.getCategoria())
              .append(" | confirmados: ").append(confirmados).append("\n");
        }
        return sb.toString();
    }
}
